## Components: 
### Arduino UNO, PIR Sensor, LED, Jumper Wires(male to male, female to male), Bread Board.


## About the project: 
### We have created an Arduino project that is used to turn on an LED connected to a PIR Sensor when motion is detected.


## Debugging:
### - connect the LED with a resistor.
### - make sure the connections are correct.
### - make sure the pin modes are set correctly(LED pin set to output, PIR Sensor set to input).
### - make sure the components are not faulty.
